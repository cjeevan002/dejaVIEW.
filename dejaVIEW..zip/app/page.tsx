"use client"

import type React from "react"
import { useState } from "react"
import Image from "next/image"
import { Loader2, Play, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { ShowData, Episode, EpisodeResult, ShowResult } from "./types"
import { Inter } from "next/font/google"
// import localFont from "next/font/local"

// const dbSans = localFont({ src: "./fonts/DBSans-Bold.woff2" })

const inter = Inter({ subsets: ["latin"] })

const ottLogos: { [key: string]: string } = {
  Netflix: "https://www.freepnglogos.com/uploads/netflix-logo-app-png-16.png",
  "Prime Video":
    "https://sjc.microlink.io/EnVthy6CNrxQ34X2Dax2F0UlklemZXZfrSowl1xSWkhNmiNNzovXorS_YFDjsYAHuesPwthLDY5oNQNo0eRSjg.jpeg",
  "Amazon Prime Video":
    "https://sjc.microlink.io/EnVthy6CNrxQ34X2Dax2F0UlklemZXZfrSowl1xSWkhNmiNNzovXorS_YFDjsYAHuesPwthLDY5oNQNo0eRSjg.jpeg",
  Hulu: "https://uxwing.com/wp-content/themes/uxwing/download/brands-and-social-media/hulu-icon.png",
  "HBO Max": "https://www.citypng.com/public/uploads/preview/hbo-max-logo-hd-png-7017516947077464d1nudkfzi.png",
  "Disney+ Hotstar":
    "https://cdn.brandfetch.io/hotstar.com/fallback/lettermark/theme/dark/h/256/w/256/icon?c=1bfwsmEH20zzEfSNTed",
  "Jio Cinema": "https://download.logo.wine/logo/Jio/Jio-Logo.wine.png",
}

export default function RandomEpisodeGenerator() {
  const [seriesName, setSeriesName] = useState("")
  const [episode, setEpisode] = useState<EpisodeResult | null>(null)
  const [show, setShow] = useState<ShowResult | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [suggestions, setSuggestions] = useState<ShowData[]>([])

  async function generateEpisode() {
    if (!seriesName.trim()) {
      setEpisode({ title: "⚠️ Please enter a series name." } as EpisodeResult)
      return
    }

    setIsLoading(true)
    setEpisode(null)
    setShow(null)

    try {
      const searchResponse = await fetch(
        `https://api.tvmaze.com/singlesearch/shows?q=${encodeURIComponent(seriesName)}`,
      )

      if (!searchResponse.ok) {
        throw new Error("Failed to fetch show data")
      }

      const showData: ShowData = await searchResponse.json()

      if (!showData || !showData.id) {
        setEpisode({ title: "⚠️ Series not found." } as EpisodeResult)
        return
      }

      const ottPlatform = showData.webChannel?.name || showData.network?.name || "Unknown"

      setShow({
        name: showData.name,
        posterUrl: showData.image?.original || showData.image?.medium || "",
        rating: showData.rating?.average || 0,
        genres: showData.genres,
        ottPlatform,
      })

      const episodesResponse = await fetch(`https://api.tvmaze.com/shows/${showData.id}/episodes`)

      if (!episodesResponse.ok) {
        throw new Error("Failed to fetch episodes")
      }

      const episodesData: Episode[] = await episodesResponse.json()

      if (!episodesData.length) {
        setEpisode({ title: "⚠️ No episodes found." } as EpisodeResult)
        return
      }

      const randomEpisode = getRandomEpisode(episodesData)
      setEpisode({
        title: randomEpisode.name,
        number: randomEpisode.number,
        season: randomEpisode.season,
        synopsis: randomEpisode.summary ? randomEpisode.summary.replace(/<[^>]+>/g, "") : "No synopsis available.",
        episodeImage:
          randomEpisode.image?.original ||
          randomEpisode.image?.medium ||
          showData.image?.original ||
          showData.image?.medium ||
          "",
        episodeLink: randomEpisode.url,
        duration: randomEpisode.runtime || showData.runtime || "N/A",
      })
    } catch (error) {
      console.error("Error fetching data:", error)
      setEpisode({ title: "⚠️ Error fetching episode details." } as EpisodeResult)
    }

    setIsLoading(false)
  }

  function getRandomEpisode(episodes: Episode[]): Episode {
    return episodes[Math.floor(Math.random() * episodes.length)]
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    generateEpisode()
  }

  const fetchSuggestions = async (query: string) => {
    if (query.length < 2) {
      setSuggestions([])
      return
    }
    try {
      const response = await fetch(`https://api.tvmaze.com/search/shows?q=${encodeURIComponent(query)}`)
      if (!response.ok) throw new Error("Failed to fetch suggestions")
      const data = await response.json()
      setSuggestions(data.map((item: { show: ShowData }) => item.show).slice(0, 5))
    } catch (error) {
      console.error("Error fetching suggestions:", error)
    }
  }

  const flipCardStyles = `
  .flip-card {
    perspective: 1000px;
  }
  .flip-card-inner {
    transition: transform 0.6s;
    transform-style: preserve-3d;
    position: relative;
  }
  .flip-card:hover .flip-card-inner {
    transform: rotateY(180deg);
  }
  .flip-card-front, .flip-card-back {
    position: absolute;
    width: 100%;
    height: 100%;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
    border-radius: 0.5rem;
  }
  .flip-card-back {
    transform: rotateY(180deg);
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  }
`

  return (
    <>
      <style jsx>{flipCardStyles}</style>
      <div
        className={`min-h-screen flex items-center justify-center bg-cover bg-center relative p-4 ${inter.className}`}
        style={{
          backgroundImage: "url(https://wallpapercave.com/wp/wp10615910.jpg)",
        }}
      >
        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />

        <Card className="w-full max-w-6xl bg-black/75 backdrop-blur-md relative z-10 border border-purple-500/20 shadow-lg shadow-purple-500/10">
          <CardHeader className="space-y-4">
            <CardTitle
              className={`text-4xl text-white text-center ${inter.className}`}
              style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.5)" }}
            >
              <span className="italic font-normal">deja</span>
              <span className="font-bold">VIEW</span>
            </CardTitle>
            <p className="text-gray-400 text-center text-sm lowercase">
              good shows deserve a rewatch. let destiny decide your next one.
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4 mb-6">
              <div className="space-y-2">
                <label htmlFor="series" className="block text-white text-center">
                  Enter Your Favorite Web Series
                </label>
                <div className="relative max-w-md mx-auto">
                  <Input
                    type="text"
                    id="series"
                    className="text-center bg-white text-black placeholder:text-gray-500"
                    placeholder="E.g., Breaking Bad"
                    value={seriesName}
                    onChange={(e) => {
                      setSeriesName(e.target.value)
                      fetchSuggestions(e.target.value)
                    }}
                    disabled={isLoading}
                  />
                  {suggestions.length > 0 && (
                    <ul className="absolute z-10 w-full bg-white border border-gray-300 rounded-md mt-1 max-h-60 overflow-auto">
                      {suggestions.map((show) => (
                        <li
                          key={show.id}
                          className="px-4 py-2 hover:bg-gray-100 cursor-pointer text-black"
                          onClick={() => {
                            setSeriesName(show.name)
                            setSuggestions([])
                          }}
                        >
                          {show.name}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              <div className="flex justify-center">
                <Button
                  type="submit"
                  className="bg-red-600 hover:bg-red-700 text-white font-bold px-8"
                  disabled={isLoading}
                >
                  {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Pick Random Episode
                </Button>
              </div>
            </form>

            {show && episode && (
              <div className="flex flex-col md:flex-row justify-center items-center md:items-stretch gap-8 mt-8">
                <div className="w-64 flex flex-col items-center">
                  <div className="flip-card w-64 h-96">
                    <div className="flip-card-inner w-full h-full">
                      <div className="flip-card-front relative w-full h-full rounded-lg overflow-hidden">
                        <Image
                          src={show.posterUrl || "/placeholder.svg"}
                          alt={show.name}
                          fill
                          className="object-cover"
                          quality={100}
                          sizes="(max-width: 768px) 100vw, 256px"
                        />
                      </div>
                      <div className="flip-card-back w-full h-full bg-black flex flex-col items-center justify-center p-4 rounded-lg relative overflow-hidden">
                        {/* Blurred background poster */}
                        <div
                          className="absolute inset-0"
                          style={{
                            backgroundImage: `url(${show.posterUrl})`,
                            backgroundSize: "cover",
                            backgroundPosition: "center",
                            filter: "blur(10px) brightness(0.3)",
                            transform: "scale(1.2)",
                          }}
                        />
                        <p className="text-white text-lg font-semibold mb-4 relative z-10">Available on:</p>
                        <div className="w-48 h-24 relative z-10 flex items-center justify-center">
                          {ottLogos[show.ottPlatform] ? (
                            <Image
                              src={ottLogos[show.ottPlatform] || "/placeholder.svg"}
                              alt={show.ottPlatform}
                              fill
                              className="object-contain mix-blend-normal"
                              sizes="192px"
                              quality={100}
                            />
                          ) : (
                            <div className="text-center">
                              <p className="text-white text-lg font-medium">{show.ottPlatform}</p>
                              <p className="text-white/60 text-sm mt-1">Streaming Service</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  <h3 className="text-white font-semibold text-xl mt-4 text-center">{show.name}</h3>
                  <div className="flex items-center justify-between mt-2 text-sm gap-4">
                    <div className="flex items-center">
                      <Star className="text-red-500 w-4 h-4 mr-1" />
                      <span className="text-white">{show.rating.toFixed(1)}</span>
                    </div>
                    <span className="text-gray-400">|</span>
                    <p className="text-gray-400">{show.genres.join(" • ")}</p>
                  </div>
                </div>

                <div
                  className="glass group relative w-full md:w-[480px] h-[384px] bg-white/10 border border-white/10 rounded-xl overflow-hidden transition-all duration-500 hover:scale-105"
                  style={{ backdropFilter: "blur(10px)" }}
                >
                  <div className="relative h-full flex flex-col">
                    {episode.episodeImage && (
                      <div className="relative h-64 w-full overflow-hidden">
                        <Image
                          src={episode.episodeImage || "/placeholder.svg"}
                          alt={`${episode.title} - Season ${episode.season}, Episode ${episode.number}`}
                          fill
                          className="object-cover object-top"
                          style={{ top: "-10%" }}
                          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 480px"
                          quality={100}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
                      </div>
                    )}
                    <div className="flex-1 p-4 pt-2 flex flex-col">
                      <h3 className={`text-white font-semibold text-2xl mb-2 ${inter.className}`}>{episode.title}</h3>
                      <div className="flex items-center mb-3">
                        <p className="text-white/80 text-sm mr-3">
                          Season {episode.season}, Episode {episode.number}
                        </p>
                        {episode.duration && <p className="text-white/60 text-sm">{episode.duration}m</p>}
                      </div>
                      <p className={`text-white/70 text-sm line-clamp-4 mb-4 ${inter.className}`}>{episode.synopsis}</p>
                      <div className="mt-auto">
                        <Button
                          className="bg-red-600 hover:bg-red-700 text-white w-full transition-colors duration-200 flex items-center justify-center gap-2"
                          onClick={() => window.open(episode.episodeLink, "_blank", "noopener,noreferrer")}
                        >
                          <Play className="h-5 w-5" /> Watch Episode
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div className="text-center mt-8">
              <span className="text-[10px] italic text-gray-400">built by</span>{" "}
              <span className="text-xs text-gray-500">JeevanChelikam</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  )
}

