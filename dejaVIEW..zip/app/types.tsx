export interface ShowData {
  id: number
  name: string
  image?: {
    medium: string
    original: string
  }
  runtime?: number
  genres: string[]
  rating?: {
    average: number
  }
  webChannel?: {
    name: string
  }
  network?: {
    name: string
  }
}

export interface Episode {
  id: number
  name: string
  number: number
  season: number
  summary: string | null
  url: string
  runtime?: number
  image?: {
    medium: string
    original: string
  }
}

export interface EpisodeResult {
  title: string
  number: number
  season: number
  synopsis: string
  episodeImage: string
  episodeLink: string
  duration: string | number
}

export interface ShowResult {
  name: string
  posterUrl: string
  rating: number
  genres: string[]
  ottPlatform: string
}

